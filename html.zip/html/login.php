<?php 			
	header("Content-type:text/html;charset=utf-8");	
	$db=new mysqli('localhost','Yize','APTX4869','clan');	
	if ($db->connect_error) {
        die('链接错误: ' . $db->connect_error);
    }
	$username=mysqli_real_escape_string($db,trim($_POST['user']));
	$password=mysqli_real_escape_string($db,trim($_POST['pass']));
	if(strlen($username)!=9){
	    echo "<alert>登录失败</alert>";
    }
	$sql = "SELECT s_id FROM student_info WHERE s_id = '$username' AND s_psword = '$password'";
	$result = $db->query($sql);
	if($username&&$password == '') {
        echo "<script> alert('学号或密码不能为空!');parent.location.href='index.html';</script>";
    } else {
        if ($result->num_rows == 0) {
            echo "<script> alert('学号或密码错误!');parent.location.href='index.html'; </script>";
        } else {
            header("location:student.html");
        }
    }