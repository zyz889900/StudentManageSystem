<?php
header("Content-type:text/html;charset=utf-8");
$db=new mysqli('localhost','Yize','APTX4869','clan');
if ($db->connect_error) {
    die('链接错误: ' . $db->connect_error);
}
$username=mysqli_real_escape_string($db,trim($_POST['user']));
$password=mysqli_real_escape_string($db,trim($_POST['pass']));
if(strlen($username)!=9){
    echo "<alert>注册失败</alert>";
}
$sql = "SELECT t_id FROM teacher_info WHERE t_id = '$username' AND t_psword = '$password'";
$result = $db->query($sql);
if($username&&$password == '') {
    echo "<script> alert('教师号或密码不能为空!');parent.location.href='index.html';</script>";
} else {
    if ($result->num_rows == 0) {
        echo "<script> alert('教师号或密码错误!');parent.location.href='index.html'; </script>";
    } else {
        header("location:teacher.html");
    }
}