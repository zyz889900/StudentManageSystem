<?php
    header("Content-type:text/html;charset=utf-8");
    $db = new mysqli('localhost', 'Yize', 'APTX4869', 'clan');
    mysqli_set_charset($db,'utf8');
    if ($db->connect_error) {
        die('连接错误: ' . $db->connect_error);
    }
    $td1=mysqli_real_escape_string($db,trim($_POST['td1']));
    $td2=mysqli_real_escape_string($db,trim($_POST['td2']));
    $td3=mysqli_real_escape_string($db,trim($_POST['td3']));
    $td4=mysqli_real_escape_string($db,trim($_POST['td4']));
    $td5=mysqli_real_escape_string($db,trim($_POST['td5']));
    $td6=mysqli_real_escape_string($db,trim($_POST['td6']));
    $sql = "INSERT INTO teacher_info VALUES ('$td1','$td2','$td3','$td4','$td5','$td6')";
    $result = mysqli_query($db, $sql);
    if ($result) {
        echo "<script> alert('添加成功');parent.location.href='student.html'; </script>";
    } else {
        echo "<script> alert('添加失败，可能原因：教师号冲突');parent.location.href='student.html'; </script>";
    }