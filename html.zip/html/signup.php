<?php
	header("Content-type:text/html;charset=utf-8");				
	$db = new mysqli('localhost','Yize','APTX4869','clan');
	mysqli_set_charset($db,'utf8');	
	if ($db->connect_error) {
        die('连接错误: ' . $db->connect_error);
    }
	$username=mysqli_real_escape_string($db,trim($_POST['user']));
    $name=mysqli_real_escape_string($db,trim($_POST['name']));
	$password=mysqli_real_escape_string($db,trim($_POST['pass']));
	$classid=mysqli_real_escape_string($db,trim($_POST['class']));
    $sql = "INSERT INTO student_info(s_id,s_name,s_psword,s_cid) VALUES ('$username','$name','$password','$classid')";
    $result = $db->query($sql);
    if ($result) {
        echo "<script> alert('注册成功！正在跳转至登录界面……');parent.location.href='index.html'; </script>";
    } else {
        echo "<script> alert('注册失败 可能原因：学号已被注册');parent.location.href='register.html'; </script>";
    }