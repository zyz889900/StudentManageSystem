window.onload=function (){
                var odiv=document.getElementById('div1');
   				var ali=odiv.getElementsByTagName('li');
                var adl=odiv.getElementsByTagName('dl');
                
                for(var i=0;i<ali.length;i++){          
                    
                    ali[i].index=i;         
                    ali[i].onclick=function (){
                        
                        for(var i=0;i<ali.length;i++){  
                        
                            adl[i].style.display='none';
                        }
                        this.className='active';
                        adl[this.index].style.display='block';
                    }
                }
            }
 