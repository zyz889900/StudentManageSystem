<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>首页</title>
    <style type="text/css">
        body{background: url("bg5.png");background-size: cover;background-attachment: fixed;color:#FFFFFF; }
        .header{height: 60PX;background-color: rgba(6, 30, 42, 0.6);color: #FFF;text-align: center;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}/*头部模块*/
        .left{position: absolute;width: 280PX;left: 0PX;bottom: 0PX;top: 70PX;background-color: rgba(6, 30, 42, 0.6);border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}/*左侧模块的位置*/
        .left .title{height: 48PX;width: 280px;line-height: 48PX;background-color: rgba(6, 30, 42, 0.6);font-size:15PX;color: white;text-align: center;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}/*系统功能*/
        #div1 {width:280px;margin:0 auto;line-height:0px;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        ul {list-style:none;}
        li {height: 60PX;line-height: 60PX;background-color: rgba(6, 30, 42, 0.6);text-align: center;border-bottom:1PX solid #053e69;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        li:hover{background-color: rgba(5, 62, 105, 0.6);color: #FFFFFF;cursor: pointer;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        dl { list-style: none;  background-color: rgba(6, 30, 42, 0.6);display: none;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        dd{  text-align: center;  color: #FFFFFF;width: 200px;line-height: 40PX;height: 40PX;border-bottom:1PX dotted #2e3449;padding-left: 0PX;box-sizing: border-box;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        dd:hover{background-color: rgba(5, 62, 105, 0.6);;color: cornflowerblue;cursor: pointer;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        .active {font-size: 20px;color: #e1e1e1;background-color: rgba(6, 30, 42, 0.6);border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        .main { border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;  position: absolute; width:auto;left: 285PX;bottom: 0PX;top: 70PX;background-color: rgba(6, 30, 42, 0.6); }
    </style>
</head>
<body>
<div class="header" style="font-size: 40px"><label>学生信息查询</label></div>
<div class="left">
    <div id="div1">
        <div class="title" style="font-size: 20px">系统功能</div>
        <ul>
            <li  class="active">课程信息模块</li>
            <dl>
                <dd><a href="kchaxun.php"><label style="color: #FFFFFF">课程信息查询</label></a></dd>
                <dd><a href="addKc.php"><label style="color: #FFFFFF">课程信息管理</label></a></dd>
            </dl>
            <li  class="active">学生成绩管理模块</li>
            <dl>
                <dd><a href=""><label style="color: #FFFFFF">学生成绩查询</label></a></dd>
                <dd><a href=""><label style="color: #FFFFFF">学生成绩管理</label></a></dd>
            </dl>
        </ul>
    </div>
</div>

<div class="main">

    <form>
        <table class="table table-responsive table-striped" id="table">

            <thead>
            <th style="font-size: 20px;color: #FFFFFF">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp序号&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
            <th style="font-size: 20px;color: #FFFFFF">课程编号&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
            <th style="font-size: 20px;color: #FFFFFF">课程名称&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
            <th style="font-size: 20px;color: #FFFFFF">课程课时&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
            <th style="font-size: 20px;color: #FFFFFF">课程类别&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
            </thead>
            <tbody id="tb">
            <?php
            $db = new mysqli('localhost', 'Yize', 'APTX4869', 'clan');
            $sql = "SELECT * FROM kecheng_info";
            $result = mysqli_query($db, $sql);
            echo "<table style='border: solid; text-align: center;'>";
            $i = 1;
            while ($row = mysqli_fetch_array($result)) {
                echo "<tr>";
                echo "<td>";
                echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
                echo $i;
                echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
                echo "</td>";
                $i++;
                echo "<td>";
                echo $row['k_id'];
                echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
                echo "</td>";
                echo "<td>";
                echo $row['k_name'];
                echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
                echo "</td>";
                echo "<td>";
                echo $row['k_keshi'];
                echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
                echo "</td>";
                echo "<td>";
                echo $row['k_kind'];
                echo "&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp";
                echo "</td>";
                echo "</tr>";
            }
            echo "</table>";
            ?>
            </tbody>
        </table>
    </form>
</div>
</body>
</html>
