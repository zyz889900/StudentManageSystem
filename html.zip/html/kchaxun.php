<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>首页</title>
    <style type="text/css">
        body{background: url("bg5.png");background-size: cover;background-attachment: fixed;color:#FFFFFF; }
        .header{height: 60PX;background-color: rgba(6, 30, 42, 0.6);color: #FFF;text-align: center;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}/*头部模块*/
        .left{position: absolute;width: 280PX;left: 0PX;bottom: 0PX;top: 70PX;background-color: rgba(6, 30, 42, 0.6);border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}/*左侧模块的位置*/
        .left .title{height: 48PX;width: 280px;line-height: 48PX;background-color: rgba(6, 30, 42, 0.6);font-size:15PX;color: white;text-align: center;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}/*系统功能*/
        #div1 {width:280px;margin:0 auto;line-height:0px;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        ul {list-style:none;}
        li {height: 60PX;line-height: 60PX;background-color: rgba(6, 30, 42, 0.6);text-align: center;border-bottom:1PX solid #053e69;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        li:hover{background-color: rgba(5, 62, 105, 0.6);color: #FFFFFF;cursor: pointer;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        dl { list-style: none;  background-color: rgba(6, 30, 42, 0.6);display: none;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        dd{  text-align: center;  color: #FFFFFF;width: 200px;line-height: 40PX;height: 40PX;border-bottom:1PX dotted #2e3449;padding-left: 0PX;box-sizing: border-box;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        dd:hover{background-color: rgba(5, 62, 105, 0.6);;color: cornflowerblue;cursor: pointer;border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        .active {font-size: 20px;color: #e1e1e1;background-color: rgba(6, 30, 42, 0.6);border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;}
        .main { border-radius: 10px;-moz-border-radius: 10px;-webkit-border-radius: 10px;-o-border-radius:10px;  position: absolute; width:auto;left: 285PX;bottom: 0PX;top: 70PX;background-color: rgba(6, 30, 42, 0.6); }
    </style>
    <script >
        window.onload=function (){
            addrows();
            var odiv=document.getElementById('div1');
            var ali=odiv.getElementsByTagName('li');
            var adl=odiv.getElementsByTagName('dl');

            for(var i=0;i<ali.length;i++){

                ali[i].index=i;
                ali[i].onclick=function (){

                    for(var i=0;i<ali.length;i++){

                        adl[i].style.display='none';
                    }
                    this.className='active';
                    adl[this.index].style.display='block';
                }
            }
        }
        function qx(){
            //获取所有的checkbox
            var checkbox = document.getElementsByName("chk");
            //遍历所有的checkbox
            for (var i=0;i<checkbox.length;i++) {
                checkbox[i].checked=true;
            }
        }
        function fx(){
            //获取所有的checkbox
            var checkbox = document.getElementsByName("chk");
            //遍历所有的checkbox
            for (var i=0;i<checkbox.length;i++) {
                checkbox[i].checked=!checkbox[i].checked;
            }
        }
        function qbx(){
            //获取所有的checkbox
            var checkbox = document.getElementsByName("chk");
            //遍历所有的checkbox
            for (var i=0;i<checkbox.length;i++) {
                checkbox[i].checked=false;
            }
        }
        var rows = 1;
        function addrows() {
            var trElement = document.createElement("tr");
            var td1Element = document.createElement("td");
            var td2Element = document.createElement("td");
            var td3Element = document.createElement("td");
            var td4Element = document.createElement("td");
            var td5Element = document.createElement("td");
            var td6Element = document.createElement("td");
            td1Element.innerHTML="<input type='checkbox' value='1' name='chk'>"+rows;
            td2Element.innerHTML="<input type='text' style='width: 172px;height:15px;' value='' required name='account' class='form-control'>";
            td5Element.innerHTML="<input type='password' style='width: 172px;height:15px;' value='' required name='account' class='form-control'>";
            td6Element.innerHTML="<input type='text' style='width: 172px;height:15px;' value='' required name='account' class='form-control'>";
            td3Element.innerHTML="<input type='text' style='width: 172px;height:15px;' value='' required name='password' class='form-control'>";
            td4Element.innerHTML="<input type=\"button\" class=\"btn btn-danger\" value=\"x\" onclick='delrow(this)'style=\"width: 20PX;height: 20PX;color:#FFFFFF; background-color:#053e69; \tborder-radius:25px;\">";

            trElement.appendChild(td1Element);
            trElement.appendChild(td2Element);
            trElement.appendChild(td3Element);
            trElement.appendChild(td5Element);
            trElement.appendChild(td6Element);
            trElement.appendChild(td4Element);

            var tbody = document.getElementById("tb");
            tbody.appendChild(trElement);
            rows++;
        }
        function delrow(obj){
            //获取按钮所在的行
            btnTrElement = obj.parentNode.parentNode;
            //alert(btnTrElement.nodeName);
            //获取按钮所在的行的上一级也就是TBODY
            tbodyElemement = btnTrElement.parentNode;
            //通过tobody干掉tr
            tbodyElemement.removeChild(btnTrElement);
        }
    </script>
</head>
<body>
<div class="header" style="font-size: 40px"><label>课程信息查询</label></div>
<div class="left">
    <div id="div1">
        <div class="title" style="font-size: 20px">系统功能</div>
        <ul>
            <li  class="active">课程信息模块</li>
            <dl>
                <dd><a href="kchaxun.html"><label style="color: #FFFFFF">课程信息查询</label></a></dd>
                <dd><a href="addKc.html"><label style="color: #FFFFFF">课程信息管理</label></a></dd>
            </dl>
            <li  class="active">学生成绩管理模块</li>
            <dl>
                <dd><a href=""><label style="color: #FFFFFF">学生成绩查询</label></a></dd>
                <dd><a href=""><label style="color: #FFFFFF">学生成绩管理</label></a></dd>
            </dl>
        </ul>
        <div style="height: 200px;"align="center" >
            <div style="height: 15px"></div>
            <div style="height: 50px"><input type="button" class="btn btn-success" value="全选" onclick="qx()" style="display:none;width: 110PX;height: 30PX;color:#FFFFFF; background-color:#053e69; 	border-radius:25px;"></div>
            <br>
            <div style="height: 50px"><input type="button" class="btn btn-warning" value="反选" onclick="fx()" style="display: none; width: 110PX;height: 30PX;color:#FFFFFF; background-color:#053e69; 	border-radius:25px;"></div>
            <br>
            <div style="height: 50px"><input type="button" class="btn btn-danger" value="全不选" onclick="qbx()" style="display: none; width: 110PX;height: 30PX;color:#FFFFFF; background-color:#053e69; 	border-radius:25px;"> </div> 
            <br>
            <div style="height: 50px"><input type="button" class="btn btn-primary" value="添加一行" onclick="addrows()" style="display: none; width: 110PX;height: 30PX;color:#FFFFFF; background-color:#053e69; 	border-radius:25px;"> </div>
        </div>
    </div>
</div>

<div class="main">

    <form>
        <table class="table table-responsive table-striped" id="table">

            <thead>
            <th style="font-size: 20px;color: #FFFFFF">序号</th>
            <th style="font-size: 20px;color: #FFFFFF">学号</th>
            <th style="font-size: 20px;color: #FFFFFF">姓名</th>
            <th style="font-size: 20px;color: #FFFFFF">密码</th>
            <th style="font-size: 20px;color: #FFFFFF">班级</th>
            <th style="font-size: 20px;color: #FFFFFF">课程号</th>
            </thead>
            <tbody id="tb">

            <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
            </tbody>
            <tfoot>
            <tr>
                <td align="center" colspan="4">
                    <div style=" margin-top:18px; padding-left: 390px;"   align="center">
                        <input  type="submit" class="btn btn-info" value="提交" style="width: 150PX;height: 30PX;color:#FFFFFF; background-color:#053e69; 	border-radius:25px;">  
                    </div>
                </td>
            </tr>
            </tfoot>
        </table>
    </form>

</div>

</body>
</html>
