<?php
    header("Content-type:text/html;charset=utf-8");
    $db = new mysqli('localhost', 'Yize', 'APTX4869', 'clan');
    mysqli_set_charset($db,'utf8');
    if ($db->connect_error) {
        die('连接错误: ' . $db->connect_error);
    }
    $td1=mysqli_real_escape_string($db,trim($_POST['td1']));
    $td2=mysqli_real_escape_string($db,trim($_POST['td2']));
    $td3=(string)mysqli_real_escape_string($db,trim($_POST['td2']));
    $sql = "INSERT INTO score_info VALUES ('$td1','$td2','$td3')";
    $result = mysqli_query($db, $sql);
    if ($result) {
        echo "<script> alert('添加成功');parent.location.href='scguanli.html'; </script>";
    } else {
        echo "<script> alert('添加失败，可能原因：班级号冲突');parent.location.href='scguanli.html'; </script>";
    }